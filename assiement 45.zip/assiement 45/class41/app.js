// Define a function to print each magician name from an array
function show_Magicians(magician) {
    magician.forEach(function (name) { return console.log(name); });
}
// Define an array containing magicians name 
var magician_name = ["Harry poter", "Hamza", "usman"];
// Call the function to print each magicians name
show_Magicians(magician_name);
