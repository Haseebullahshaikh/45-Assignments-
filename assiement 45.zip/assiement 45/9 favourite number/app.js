var favNumber = 10;
var message = "Mine Favourite Number is:";
console.log(message, favNumber);
