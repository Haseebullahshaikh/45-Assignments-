let favNumber = 10;
let message = "Mine Favourite Number is:";
console.log(message, favNumber);