var userName = ["haseeb", "zeeshan", "uzair", "admin", "shahzaib",];
if (userName.length === 0) {
    console.log("your Array in Empty We need to find some users!");
}
else {
    // using forEach loop on Array
    userName.forEach(function (oneUser) {
        if (oneUser === "admin") {
            console.log('Hello ${oneUser}, would you like to see a status report?');
        }
        else {
            console.log('Hello ${oneUser}, thank you for loading in again.');
        }
    });
}
