// Creatina a Array
let favorite_fruit = ["Mango","strawberry","orange"]


// using 5 independent if statment 
if (favorite_fruit.includes("Mango")){
    console.log("I Really like to mango");
}
if (favorite_fruit.includes("strawberry")){
    console.log("I Really like strawberry")
}
if (favorite_fruit.includes("apple")){
    console.log("I Really like apple")
}
if (favorite_fruit.includes("orange")){
    console.log("I Really like orange")
}
if (favorite_fruit.includes("banana")){
    console.log("I Really like banana")
}