// creating a guestList Array
var guestList = ["Maria", "Daffodils", "Umme", "Mickey"];
// variable for those guest who cant come
var dontCome = guestList[1];
// Printing the name of guest who cant come
console.log(dontCome, "Nahi Aa Sakti");
// Add or Remove Values from guestList Array
guestList.splice(1, 2, "Muqaddas");
// Message print for Bigger Table
console.log("good News ! we have found a Bigger Table for aftar");
// Adding a new guest at starting index of Array
guestList.unshift("Ayesha");
// Adding a new guest at ending index of Array
guestList.push("Muqaddas");
// Get a middle index of our guestList Array
var middleIndex = Math.floor(guestList.length / 2);
// Adding a new guest at middle index of Array
guestList.splice(middleIndex, 0, "Jia");
// print messgae for updated list
console.log("Updated List of our guests");
// sending the invitation message to our guests one by one with their names
guestList.forEach(function (oneGuest) { return console.log("Salam ".concat(oneGuest, ", would you like to aftar with me")); });
// inform that only two guests invite for aftar
console.log("unfortunately, the new aftar table wont arrive on time, so I can only invite two guests to aftar with me");
// using whileloop to remove guests from the Array until only two names remain
while (guestList.length > 2) {
    var removedGuest = guestList.pop();
    console.log("Sorry, ".concat(removedGuest, " I cant invite you to aftar"));
}
// sending invitations to the last two guests on the list
console.log("Invitations to the last 2 guests");
guestList.forEach(function (lastTwo) { return console.log("Luckily ".concat(lastTwo, ", you are still invited to aftar")); });
// removing last two guests from the list
guestList.pop();
guestList.pop();
console.log("emptyList:, guestList");
