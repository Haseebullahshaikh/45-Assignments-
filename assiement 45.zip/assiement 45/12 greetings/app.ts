let friendsName = ["Neha" , "Aqsa" , "Mickey" , "Cindrella"];

friendsName.forEach(friendName => console.log(`Hello ${friendName}, How are you`));