var friendsName = ["Neha", "Aqsa", "Mickey", "Cindrella"];
friendsName.forEach(function (friendName) { return console.log("Hello ".concat(friendName, ", How are you")); });
