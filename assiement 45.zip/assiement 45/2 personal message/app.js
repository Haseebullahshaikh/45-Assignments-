"use strict";
let personName = "Hello Eric, Would You Like To Learn Some Python Today?";
console.log(personName);
