var guestList = ["Maria", "Daffodils", "Umme"];
guestList.forEach(function (oneGuest) { return console.log("Salam ".concat(oneGuest, ", would you like to aftar with me?")); });
