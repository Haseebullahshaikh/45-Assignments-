let guestList = ["Maria" , "Daffodils" , "Umme"];

guestList.forEach(oneGuest => console.log(`Salam ${oneGuest}, would you like to aftar with me?`));