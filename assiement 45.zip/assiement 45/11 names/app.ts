let friendsName = ["Neha, Aqsa,Mickey,Cindrella"];

console.log(friendsName);