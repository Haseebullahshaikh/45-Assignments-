// define varaible
var aliencolor = "green";
if (aliencolor === "green") {
    console.log("player just earned 5 points for shooting the alien.");
}
else {
    console.log("player just earned 10 points.");
}
// second variable
if (aliencolor === "blue") {
    console.log("I am come form if statmten.");
}
else {
    console.log("I am come form elsa statment");
}
