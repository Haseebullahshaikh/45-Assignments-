let famousPerson = "Albert Einstein";

let message = "once said,\"A person who never made a mistake never tried anyhing new\"";

console.log(famousPerson, message);