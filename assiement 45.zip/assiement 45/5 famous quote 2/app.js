var famousPerson = "Albert Einstein";
var message = "once said,\"A person who never made a mistake never tried anyhing new\"";
console.log(famousPerson, message);
