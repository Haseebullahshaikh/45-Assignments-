// creating Array
let errorArray: string[] = ["A","B","C","D"];

// producing error ! by accessing invalid index of Array
console.log(errorArray[10]);

// error removed
console.log(errorArray[1]);