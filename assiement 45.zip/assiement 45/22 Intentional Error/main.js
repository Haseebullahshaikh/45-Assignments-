// creating Array
var errorArray = ["A", "B", "C", "D"];
// producing error ! by accessing invalid index of Array
console.log(errorArray[10]);
console.log(errorArray[1]);
