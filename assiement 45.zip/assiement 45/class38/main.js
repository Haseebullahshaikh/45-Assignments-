// describe a function 
function describe_city(city, country) {
    if (country === void 0) { country = "pakistan"; }
    console.log('${city} is in ${country}');
}
// Calling the funcation 
describe_city("karachi");
describe_city("Lahore");
describe_city("berlin", "germany");
