interface itCourse{
    courseName: String;
    location: String;
    onSiteStudents: number;
}

let  itCourse = {
    courseName: "Typescript and Javascript",
    location: "Governor House Sindh",
    onSiteStudents: 50000
};

console.log(itCourse);