var itCourse = {
    courseName: "Typescript and Javascript",
    location: "Governor House Sindh",
    onSiteStudents: 50000
};
console.log(itCourse);
