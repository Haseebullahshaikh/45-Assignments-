// Addition 
console.log(4+4);

// Subtraction

console.log(12-4);

// Multiplication
console.log(2*4);

// Division
console.log(16/2);