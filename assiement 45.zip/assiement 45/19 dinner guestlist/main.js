var guestList = ["Maria", "Jia", "Daffodils", "Umme"];
// guestList.forEach(oneGuest => console.log(`Salam ${oneGuest}, would you like to aftar with me?`));
var lengthGuests = guestList.length;
console.log("we are Invitating total ".concat(lengthGuests, " guests."));
