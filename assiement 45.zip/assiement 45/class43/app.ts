// Define the function to show magicians names
function show_magicians(magicians: string[]){
    magicians.forEach(name => console.log (name));
}

function make_great(magicians: string[]){
    return magicians.map(name => 'The great ${name}');
}


// Define an array of magicians names
let magicians_names =["Harry poter","Hamza","usman"];

// Making a copied array though.slice() function
let copy_magicians_names = magicians_names.slice();

// Modify the copied array to include "The great" with their names 
let copy_great_magician = make_great(copy_magicians_names);

// show both array orginal and copied

// orginal
console.log("\ncopied Array\b")
show_magicians(magicians_names);

// Copied
console.log("\ncopied Array\n")
show_magicians(magicians_names);