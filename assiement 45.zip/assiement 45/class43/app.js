// Define the function to show magicians names
function show_magicians(magicians) {
    magicians.forEach(function (name) { return console.log(name); });
}
function make_great(magicians) {
    return magicians.map(function (name) { return 'The great ${name}'; });
}
// Define an array of magicians names
var magicians_names = ["Harry poter", "Hamza", "usman"];
// Making a copied array though.slice() function
var copy_magicians_names = magicians_names.slice();
// Modify the copied array to include "The great" with their names 
var copy_great_magician = make_great(copy_magicians_names);
// show both array orginal and copied
// orginal
console.log("\ncopied Array\b");
show_magicians(magicians_names);
// Copied
console.log("\ncopied Array\n");
show_magicians(magicians_names);
