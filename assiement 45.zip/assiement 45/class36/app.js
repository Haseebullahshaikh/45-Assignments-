function make_shirt() { }
(function (size, printMessage) {
    console.log('you selectsd $(size) size shirt with ${printMessage} print on shirt');
});
make_shirt("Meduim", "Code with Hamza");
