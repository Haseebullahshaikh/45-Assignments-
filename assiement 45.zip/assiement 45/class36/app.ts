function make_shirt = (size:string,printMessage){
    console.log('you selectsd $(size) size shirt with ${printMessage} print on shirt')
}

make_shirt("Meduim","Code with Hamza")