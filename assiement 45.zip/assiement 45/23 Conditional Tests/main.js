// making a variables 
var five = 5;
var ten = 10;
// Test 1
console.log("Test 1: five is equal to 5");
console.log(five == 5);
// test 2 
console.log("\nTest 2: ten is equal to 10");
console.log(ten == 10);
// Test 3
console.log("\nTest 3: five is not equal to 10");
console.log(five != ten);
// Test 4
console.log("\nTest 4: ten is greater than 5");
console.log(ten > 5);
// Test 5
console.log("\nTest 5: five is smaller than 10");
console.log(five < 10);
// Test 6
console.log("\nTest 6: ten is smaller than 5");
console.log(10 < 5);
// Test 7
console.log("\nTest 7: five is equal to ten");
console.log(five == 10);
// Test 8
console.log("\nTest 8: 10 is not equal to 10");
console.log(10 != 10);
// Test 9
console.log("\nTest 9: 5 is greater than 10");
console.log(5 > 10);
// Test 10
console.log("\nTest 10: 100 is smaller than 50");
console.log(100 < 50);
