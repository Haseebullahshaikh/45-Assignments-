let whitespaceName = "\n\t Jaweria Shaikh \t\n";
console.log(whitespaceName);

let withoutWhitespaceName = whitespaceName.trim();

    console.log (withoutWhitespaceName)