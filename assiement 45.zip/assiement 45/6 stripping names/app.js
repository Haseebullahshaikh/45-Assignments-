var whitespaceName = "\n\t Jaweria Shaikh \t\n";
console.log(whitespaceName);
var withoutWhitespaceName = whitespaceName.trim();
console.log(withoutWhitespaceName);
