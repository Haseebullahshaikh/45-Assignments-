let alienColor = "Black";
