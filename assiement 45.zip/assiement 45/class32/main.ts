// Array of current Urser
let current_user = ["Usman","ali","Areeb","zain","osama"]

// Array of new Users
let new_users = ["Hamza","Ayesha","Ali","MAhad","Areeba"]

// Loop though new_users to chech for usernames avaibility

// Making a condition for username already exist and save in our_codition variable
new_users.forEach(new_one_user => {
    let our_condition = current_user.some(current_one_user => current_one_user.toLowerCase() === new_one_user.toLowerCase())

    // Print Different massage using If_Elsa statment
    if(our_condition){
        console.log("sorry ${new_one_user}' is already taken!")
    }else{
        console.log("this usersname $ (new_one_user) is available")
    }
})
