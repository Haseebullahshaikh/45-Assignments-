var transportationModes = ["sport Bike", "Bus", "Car", "sport Car"];
transportationModes.forEach(function (mode) { return console.log("I would like to own a ".concat(mode)); });
