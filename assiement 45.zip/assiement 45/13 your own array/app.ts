let transportationModes = ["sport Bike" , "Bus" , "Car" , "sport Car"];

transportationModes.forEach(mode => console.log(`I would like to own a ${mode}`));