var guestList = ["Maria", "Daffodils", "Umme"];
var dontCome = guestList[1];
console.log(dontCome, "Nahi Aa Sakti");
guestList.splice(1, 1, "Muqaddas");
guestList.forEach(function (guest) { return console.log("Salam ".concat(guest, ", would you like to aftar with me?")); });
