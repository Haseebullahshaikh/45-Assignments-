let guestList = ["Maria" , "Daffodils" , "Umme"];

let dontCome = guestList[1];

console.log(dontCome, "Nahi Aa Sakti");

guestList.splice(1, 1, "Muqaddas");

guestList.forEach(guest => console.log(`Salam ${guest}, would you like to aftar with me?`));