function storecarInfo(maunfacturer: string, modelname: string,  ...extraOption: {[key : string]: any}[] ):
object {

    const carInfo = {
        maunfacturer,
        modelname,
        ...Object.assign({}, ...extraOption)
    }
    return carInfo;
};

let answare = storecarInfo('Honda','clivi',{color :'blank'}, {features: ['navigation','power window']})

console.log(answare)
