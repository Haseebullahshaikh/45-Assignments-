// creating a guestList Array
let guestList = ["Maria" , "Daffodils" , "Umme" , "Mickey"];

// variable for those guest who cant come
let dontCome = guestList[1];

// Printing the name of guest who cant come
console.log (dontCome, "Nahi Aa Sakti");

// Add or Remove Values from guestList Array
guestList.splice(1,  2, "Muqaddas");

// Message print for Bigger Table
console.log("good News ! we have found a Bigger Table for aftar");

// Adding a new guest at starting index of Array
guestList.unshift("Ayesha");

// Adding a new guest at ending index of Array
guestList.push("Muqaddas");

// Get a middle index of our guestList Array
let middleIndex: number = Math.floor(guestList.length / 2);

// Adding a new guest at middle index of Array
guestList.splice(middleIndex, 0, "Jia");

// print messgae for updated list
console.log("Updated List of our guests");

// sending the invitation message to our guests one by one with their names
guestList.forEach(oneGuest => console.log(`Salam ${oneGuest}, would you like to aftar with me`));