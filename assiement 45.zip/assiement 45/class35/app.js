// creating a Array 
var petAnimals = ["cat", "dog", "rabbit"];
// Using for-loop
for (var _i = 0, petAnimals_1 = petAnimals; _i < petAnimals_1.length; _i++) {
    var _onepet = petAnimals_1[_i];
    console.log('A ${onepet} would make a great pet.');
}
// print a Massage outside of for-loop
console.log("Any of these animals would make a great pet!/n");
