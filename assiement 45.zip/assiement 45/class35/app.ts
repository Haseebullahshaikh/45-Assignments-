// creating a Array 
let petAnimals = ["cat", "dog", "rabbit"]

// Using for-loop
for (let onepet of petAnimals){
       console.log('A ${onepet} would make a great pet.' ) 
    }

// print a Massage outside of for-loop
console.log("Any of these animals would make a great pet!/n")