// define varaible
var aliencolor = "green";
// using if and Elsa-If statment
if (aliencolor === "green") {
    console.log("you shot down green alien you have earned 5 points");
}
else if (aliencolor === "yello") {
    console.log("you shot down green alien you have earned 10 points");
}
else if (aliencolor === "red") {
    console.log("you shot down red alien you have earned 15 points");
}
// version 2
if (aliencolor === "green") {
    console.log("you shot down green alien you have earned 5 points");
}
else if (aliencolor === "yello") {
    console.log("you shot down green alien you have earned 10 points");
}
else if (aliencolor === "red") {
    console.log("you shot down red alien you have earned 15 points");
}
//version 3
if (aliencolor === "green") {
    console.log("you shot down green alien you have earned 5 points");
}
else if (aliencolor === "yello") {
    console.log("you shot down green alien you have earned 10 points");
}
else if (aliencolor === "red") {
    console.log("you shot down red alien you have earned 15 points");
}
