var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
// making an Arrayy of countries and print its original order
var countriesToVisit = ["Paris", "Makkah", "Madina", "Italy"];
console.log("Original Order:", countriesToVisit);
// print the Array in Alphabeical Order without modifying the actual Array List
console.log("Alphabetical Oredr:", __spreadArray([], countriesToVisit, true).sort());
// show that the Array is still in the Original Order
console.log("Still in Original Order:", countriesToVisit);
// print the Array in reversed Order witout modifying the actual Array List
console.log("Reverse Order:", __spreadArray([], countriesToVisit, true).reverse());
// show that the Array is still in the Original Order
console.log("Still in Original Order:", countriesToVisit);
// we have changed the Original Array Order now
console.log("Original Array Reversed:", countriesToVisit.reverse());
// print the Array to show its Back to its Original Order
console.log("Back to Original Order:", countriesToVisit.reverse());
// print the Array to show its order has changed in Alphabetical order now
console.log("Sorted in Alphabetical Order:", countriesToVisit.sort());
// we have changed the Original Array Order nowin reverse order again
console.log("Original Array Reversed Again:", countriesToVisit.reverse());
