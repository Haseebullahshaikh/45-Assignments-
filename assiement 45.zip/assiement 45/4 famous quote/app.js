console.log("Albert Einstein once said,\"A person who never made amistake necer tried anything new.\"");
