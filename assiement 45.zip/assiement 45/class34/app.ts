// creation a Array
let pizza = ["chicken tike","malai cheese","fajita"]

// using for-loop
for(let onepizza of pizza){
    console.log('I Like ${onepizza}pizza');
}

// print a Massage outside of the for-loop
console.log("pizza is love")