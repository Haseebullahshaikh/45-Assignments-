// Making a function 

function Make_shirt (size: string = "large",printMessage: string = "I love typescirpt"){
   console.log('creation a${size} shirt with the ${printMessage} print on shirt' )
}
// calling a function with by-default message
Make_shirt()

// Calling a function now with Medium size default message
Make_shirt("Medium")

// Calling a function now with small size amd also Different print Message
Make_shirt("Small","I love javescirpt")