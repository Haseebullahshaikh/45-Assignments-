let personName = "Jaweria";

console.log(personName.toLowerCase());
console.log(personName.toUpperCase());
console.log(personName.replace(/\bw/g, c => c.toUpperCase()));