// Define a funtion with a rest parmeter the accept items arugment repesenting our sandwish
function makesandwish(...items: string[]){
      console.log("/nMaking a sandwish with the following items: \n");

      items.forEach(singleItem => console.log(singleItem));

      console.log("\nNow Enjoy sandwish");
}

// Call the funtion 3 items with 3 different number of argument 
makesandwish("Chicken","cheese","Mayo","Egg");

makesandwish("bread","butter");

makesandwish("Chicken","cheese","Mayo","Egg","bread","butter");