// define variables
var apple = "apple";
var uppercaseApple = "APPLE";
var ten = 10;
var twenty = 20;
var fruits = ["aple", "banana", "mango"];
// Test for equality an inequality with strings
console.log("Is apple is equal to apple?");
console.log(apple == apple);
console.log("Is apple is not equal to apple?");
console.log(apple != apple);
// Test using the lowercase function
console.log("\nIs APPLE is equal to apple after converting to lowercase?");
console.log(uppercaseApple.toLowerCase() == "apple");
console.log("Is ApplE is not equal to apple after converting to lowercase?");
console.log(uppercaseApple.toLowerCase() != "apple");
// Numerical tests
// Equal to
console.log("\nIs ten is equal to twenty?");
console.log(ten == twenty);
// Not equal to
console.log("\nIs ten is not equal to twenty?");
console.log(ten != twenty);
// greater than
console.log("\nIs ten is greater than 0?");
console.log(ten > 0);
// less than
console.log("\nIs twenty is less than ten?");
console.log(twenty < 10);
// Greater than or Equal to
console.log("\nIs ten is greater than or equal to 5?");
console.log(ten >= 5);
// Less than or Eual to
console.log("\nIs twenty is less than or equal to 10?");
console.log(twenty <= 10);
// Tests using "and" & "OR"
// using &&
console.log("\ntwenty is not equals to ten and twenty is greater than ten");
console.log(twenty != ten && twenty > ten);
console.log("\n twenty is not equal to 10 and twenty is greater than 10");
console.log(twenty != 10 && twenty > 30);
// using || (OR)
console.log("\n 20 is greater than 50 OR 20 is equal 20");
console.log(20 > 50 || 20 == 20);
console.log("\n 20 is greater than 50 OR 20 is not equal to 20");
console.log(20 > 50 || 20 != 20);
// Test whether an item is including in Array
console.log("\n Is mango include in my fruits array");
console.log(fruits.includes("mango"));
console.log("\n Is mango not includes in my fruits array");
console.log(!fruits.includes("mango"));
