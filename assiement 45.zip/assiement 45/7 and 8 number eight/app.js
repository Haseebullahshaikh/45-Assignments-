console.log(4 + 4);
console.log(12 - 4);
console.log(2 * 4);
console.log(16 / 2);
