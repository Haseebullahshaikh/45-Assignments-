// creating a function with parameters which return a value in string 
function city_country(city, country) {
    return '${city}, ${country}';
}
// Calling a function and pirnt the returned value
console.log(city_country("karachi", "pakistan"));
console.log(city_country("Tokyo", "japan"));
console.log(city_country("berlin", "germany"));
