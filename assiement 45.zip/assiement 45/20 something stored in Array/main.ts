// making a programming languages Array
let programmingLanguages:String[]=["Typescript","Javascript","Python","C++"];

// print a message of list
console.groupCollapsed("List of programmingLanguages:");

// print the values of Array in the form of list
programmingLanguages.forEach(language => console.log(language));