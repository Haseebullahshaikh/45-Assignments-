// making a programming languages Array
var programmingLanguages = ["Typescript", "Javascript", "Python", "C++"];
// print a message of list
console.groupCollapsed("List of programmingLanguages:");
// print the values of Array in the form of list
programmingLanguages.forEach(function (language) { return console.log(language); });
