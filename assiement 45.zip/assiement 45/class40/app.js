// Define the make_album function
function make_album(artlist_name, album_title, tracks) {
    var album = {
        artlist: artlist_name,
        title: album_title,
    };
    if (tracks !== undefined) {
        album.tracks = tracks;
    }
    return album;
}
// Calling three function with different values
var album1 = make_album("Hamza", "Album title 1");
var album2 = make_album("usman", "Album title 2");
// Calling a make_album function with third parameter 
var album3 = make_album("ali", "Album title3", 10);
//
console.log(album1);
console.log(album2);
console.log(album3);
