// creating a Array
var userName = ["haseeb", "zeeshan", "uzair", "admin", "shahzaib",];
// using forEach loop on Array
userName.forEach(function (oneUser) {
    if (oneUser === "admin") {
        console.log('Hello ${oneUser}, would you like to see a status report?');
    }
    else {
        console.log('Hello ${oneUser}, thank you for loading in again.');
    }
});
